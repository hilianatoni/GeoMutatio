-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE logradouro (
cep varchar(11),
idlogradouro int auto_increment PRIMARY KEY,
nomlogradouro varchar(80)
);

CREATE TABLE user (
email varchar(80),
numresi int,
cpf varchar(14) PRIMARY KEY,
complemento varchar(500),
nome varchar(80),
rg varchar(11),
idlogradouro int,
FOREIGN KEY(idlogradouro) REFERENCES logradouro (idlogradouro)
);

CREATE TABLE tipuser (
desctipuser varchar(80),
idtipuser int auto_increment PRIMARY KEY
);

CREATE TABLE cidade (
idcidade int auto_increment PRIMARY KEY,
nomcidade varchar(80),
iduf int
);

CREATE TABLE departamento (
nomdep varchar(80),
idep int auto_increment PRIMARY KEY,
cnpj varchar(13)
);

CREATE TABLE empresa (
nomempresa varchar(80),
razaosocial varchar(80),
cnpj varchar(13) PRIMARY KEY
);

CREATE TABLE bairro (
idbairro int auto_increment PRIMARY KEY,
nombairro varchar(80),
idcidade int,
FOREIGN KEY(idcidade) REFERENCES cidade (idcidade)
);

CREATE TABLE possui (
idtipuser int,
cpf varchar(14),
idep int auto_increment,
pdtf date not null,
pdti date not null,
PRIMARY KEY(cpf,idep),
FOREIGN KEY(idtipuser) REFERENCES tipuser (idtipuser)
);

CREATE TABLE pertence (
idbairro int,
idlogradouro int,
FOREIGN KEY(idbairro) REFERENCES bairro (idbairro),
FOREIGN KEY(idlogradouro) REFERENCES logradouro (idlogradouro)
);

CREATE TABLE uf (
nomuf varchar(80),
iduf int auto_increment PRIMARY KEY
);

ALTER TABLE cidade ADD FOREIGN KEY(iduf) REFERENCES uf (iduf);
ALTER TABLE departamento ADD FOREIGN KEY(cnpj) REFERENCES empresa (cnpj);
